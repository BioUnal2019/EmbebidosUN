import esp32
import time
import network
import machine
import ubinascii
from machine import UART
from umqttsimple import MQTTClient
#####libraries#####

wlan = network.WLAN(network.STA_IF) # create station interface
wlan.active(True) # activate the interface
wlan.connect('RaspiEmmanuel', 'emmanuel') # connect to an AP
print(wlan.ifconfig()
)	# print the interface's IP/netmask/gw/DNS addresses 


server='192.168.4.1'
port=1883
user=''
passwd=''
CLIENT_ID = ubinascii.hexlify(machine.unique_id()) #get a client ID
mqtt = MQTTClient(CLIENT_ID, server, port, user, passwd) #connect to mqtt server

uart = UART(1,9600) #initialize the uart at 9600 bauds
for count in range(10):
  mqtt.connect()
  mqtt.publish('temperatura' , (uart.read())) #publis the data from the uart in the mqett server
  mqtt.disconnect()
  time.sleep(1) #wait 1 second 

