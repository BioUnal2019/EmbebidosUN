# This file is executed on every boot (including wake-boot from deepsleep)
#import esp
#esp.osdebug(None)

import network
from machine import Pin
from time import sleep

led = Pin(2, Pin.OUT)

led.on()
sleep(0.2)
led.off()

ap = network.WLAN(network.AP_IF) #create an acces point to connect webRPL
ap.active(True) #activate the acces point 
ap.config(essid='ESP32_BOARD.1') #assign the name of the acces point 
ap.config(authmode=3, password='12345678') #assign the password of the acces point 

wlan = network.WLAN(network.STA_IF) # create station interface
wlan.active(True)       # activate the interface
wlan.connect('RaspiEmmanuel', 'Emmanuel') # connect to an AP
wlan.ifconfig()         # get the interface's IP/netmask/gw/DNS addresses

import webrepl
webrepl.start()

led.on()

